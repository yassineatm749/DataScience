# eprediction
covid-19 spread in morocco


// Very important

I m working with python 3.7.6 (64 bit)


// Go to your project directory

cd project_directory_path


// Create a virtual environement called "venv" where you will install all your dependencies

python -m venv venv


// Activate your virtual environement 

// For windows

venv\scripts\activate

//For linux & mac

source venv/bin/activate



// Install all modules needed for the project

pip install flask

pip install pandas

pip install pmdarima

pip install apscheduler

pip install requests

pip install ChatterBot==1.0.5

pip install chatterbot-corpus  or pip3 install chatterbot_corpus


// Run the app

python app.py


//if you got a "module not found error" install the required module with:

pip install required_module


// Then go to your browser at "http://127.0.0.1:3000/" and enjoy
